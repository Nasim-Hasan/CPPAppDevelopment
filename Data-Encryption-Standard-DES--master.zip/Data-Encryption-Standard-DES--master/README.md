# Data-Encryption-Standard-DES-
Implementation of Data Encryption Standard (DES) in C
